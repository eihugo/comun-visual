import 'dotenv/config';

const obrigatoria = (nome) => {
  if (!process.env[nome]) throw new Error(`Variável ${nome} não definida no .env`);
  return process.env[nome];
};

export const env = {
  port: Number(process.env.PORT || 3000),
  databaseUrl: obrigatoria('DATABASE_URL'),
  jwtSecret: obrigatoria('JWT_SECRET'),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
  isProd: process.env.NODE_ENV === 'production',
};
