import { z } from 'zod';

const perfil = z.enum(['admin', 'gerente', 'vendedor', 'designer', 'producao', 'financeiro']);

export const criarUsuarioSchema = z.object({
  nome: z.string().trim().min(2).max(150),
  email: z.string().trim().toLowerCase().email(),
  senha: z.string().min(8).max(100),
  perfil,
  limite_desconto_percentual: z.number().min(0).max(100).optional(),
});

export const atualizarUsuarioSchema = z
  .object({
    nome: z.string().trim().min(2).max(150),
    perfil,
    limite_desconto_percentual: z.number().min(0).max(100),
    ativo: z.boolean(),
    senha: z.string().min(8).max(100),
  })
  .partial()
  .refine((d) => Object.keys(d).length > 0, 'Informe ao menos um campo');
