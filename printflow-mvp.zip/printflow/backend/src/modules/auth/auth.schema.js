import { z } from 'zod';

export const registrarSchema = z.object({
  empresa: z.object({
    nome: z.string().trim().min(2).max(150),
    cnpj: z.string().trim().max(18).optional(),
    email: z.string().trim().email().optional(),
  }),
  admin: z.object({
    nome: z.string().trim().min(2).max(150),
    email: z.string().trim().toLowerCase().email(),
    senha: z.string().min(8, 'A senha deve ter ao menos 8 caracteres').max(100),
  }),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  senha: z.string().min(1),
});
